/*
* Proyecto de Computación Gráfica - Modelos Dinámicos y Estáticos con Iluminación
*/

#include <iostream>
#include <stdlib.h>

// GLAD: Multi-Language GL/GLES/EGL/GLX/WGL Loader-Generator
#include <glad/glad.h>

// GLFW
#include <GLFW/glfw3.h>

// GLM: OpenGL Math library
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Model loading classes
#include <shader_m.h>
#include <camera.h>
#include <model.h>
#include <animatedmodel.h>
#include <material.h>
#include <light.h>
#include <cubemap.h>

#include <irrKlang.h>
using namespace irrklang;

// Functions
bool Start();
bool Update();

// Definición de callbacks
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);

// Gobals
GLFWwindow* window;

// Tamaño en pixeles de la ventana
const unsigned int SCR_WIDTH = 1024;
const unsigned int SCR_HEIGHT = 768;

// Definición de cámara (posición en XYZ)
Camera camera(glm::vec3(0.0f, 2.0f, 10.0f));

// Controladores para el movimiento del mouse
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;

// Variables para la velocidad de reproducción
float deltaTime = 0.0f;
float lastFrame = 0.0f;
float elapsedTime = 0.0f;

// Variables para movimiento de personaje
glm::vec3 position(0.0f, 0.0f, 0.0f);
glm::vec3 forwardView(0.0f, 0.0f, 1.0f);
float scaleV = 0.005f;
float rotateCharacter = 0.0f;

// Shaders
Shader* staticShader;       // Para modelos estáticos
Shader* dynamicShader;      // Para modelos animados
Shader* mLightsShader;      // Para iluminación
Shader* basicShader;        // Shader básico
Shader* cubemapShader;      // Para el skybox

// Modelos
Model* house;               // Modelo de casa
Model* chair, * table, * sillon, * florero, * lamp, * librero, * librero2, * tv; // Muebles
AnimatedModel* character;   // Personaje animado

// Modelos para materiales
Model* sphere;
Model* esferamarmol, * esferamadera, * esferaoro, * esferacobre, * esferabronce, * esferacristal;
Model* Table02;
Model* lightDummy;

// Cubemap
CubeMap* mainCubeMap;

// Materiales
Material material1, material2, material3, material4, material5, material6, material7, material8;

// Luces
std::vector<Light> gLights;

// Audio
ISoundEngine* SoundEngine = createIrrKlangDevice();

// Funciones auxiliares para luces
void SetLightUniformInt(Shader* shader, const char* propertyName, size_t lightIndex, int value);
void SetLightUniformFloat(Shader* shader, const char* propertyName, size_t lightIndex, float value);
void SetLightUniformVec4(Shader* shader, const char* propertyName, size_t lightIndex, glm::vec4 value);
void SetLightUniformVec3(Shader* shader, const char* propertyName, size_t lightIndex, glm::vec3 value);

int main()
{
    if (!Start())
        return -1;

    while (!glfwWindowShouldClose(window))
    {
        if (!Update())
            break;
    }

    glfwTerminate();
    return 0;
}

bool Start() {
    // Inicialización de GLFW
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Creación de la ventana
    window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Proyecto Modelos Dinámicos y Estáticos", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // glad: Cargar todos los apuntadores
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return false;
    }

    // Activación de buffer de profundidad
    glEnable(GL_DEPTH_TEST);

    // Compilación y enlace de shaders
    dynamicShader = new Shader("shaders/09_vertex_skinning.vs", "shaders/09_fragment_skinning.fs");
    staticShader = new Shader("shaders/10_vertex_simple.vs", "shaders/10_fragment_simple.fs");
    mLightsShader = new Shader("shaders/11_PhongShaderMultLights.vs", "shaders/11_PhongShaderMultLights.fs");
    basicShader = new Shader("shaders/10_vertex_simple.vs", "shaders/10_fragment_simple.fs");
    cubemapShader = new Shader("shaders/10_vertex_cubemap.vs", "shaders/10_fragment_cubemap.fs");

    // Configuración máxima de huesos para modelos animados
    dynamicShader->setBonesIDs(MAX_RIGGING_BONES);

    // Carga de modelos estáticos
    house = new Model("models/casaj.fbx");
    chair = new Model("models/chair.fbx");
    table = new Model("models/table.fbx");
    sillon = new Model("models/sillon.fbx");
    florero = new Model("models/florero.fbx");
    lamp = new Model("models/lamp.fbx");
    librero = new Model("models/librero.fbx");
    librero2 = new Model("models/librero2.fbx");
    tv = new Model("models/tv.fbx");

    // Carga de modelos para materiales
    sphere = new Model("models/IllumModels/Sphere.fbx");
    esferamarmol = new Model("models/esferamarmol.fbx");
    esferamadera = new Model("models/esferamadera.fbx");
    esferaoro = new Model("models/esferaoro.fbx");
    esferacobre = new Model("models/esferacobre.fbx");
    esferabronce = new Model("models/esferabronce.fbx");
    esferacristal = new Model("models/esferacristal.fbx");
    Table02 = new Model("models/IllumModels/Table02.fbx");
    lightDummy = new Model("models/IllumModels/lightDummy.fbx");

    // Carga de modelo animado (guerrero mongol)
    character = new AnimatedModel("models/Caballito.fbx");

    // Configuración del cubemap
    vector<std::string> faces
    {
        "textures/cubemap/01/posx.png",
        "textures/cubemap/01/negx.png",
        "textures/cubemap/01/posy.png",
        "textures/cubemap/01/negy.png",
        "textures/cubemap/01/posz.png",
        "textures/cubemap/01/negz.png"
    };
    mainCubeMap = new CubeMap();
    mainCubeMap->loadCubemap(faces);

    // Configuración de luces
    Light light01;
    light01.Position = glm::vec3(9.0f, 5.0f, 5.0f);
    light01.Color = glm::vec4(0.33f, 0.33f, 0.33f, 1.0f);
    light01.Power = glm::vec4(30.0f, 30.0f, 30.0f, 1.0f);
    light01.alphaIndex = 200;
    gLights.push_back(light01);

    // Configuración de materiales
    // Material 1 - marmol
    material1.ambient = glm::vec4(0.7f, 0.7f, 0.7f, 1.0f);
    material1.diffuse = glm::vec4(0.8f, 0.8f, 0.8f, 1.0f);
    material1.specular = glm::vec4(0.9f, 0.9f, 0.9f, 1.0f);
    material1.transparency = 1.0f;

    // Material 2 - madera
    material2.ambient = glm::vec4(0.4f, 0.3f, 0.2f, 1.0f);
    material2.diffuse = glm::vec4(0.6f, 0.5f, 0.4f, 1.0f);
    material2.specular = glm::vec4(0.2f, 0.2f, 0.2f, 1.0f);
    material2.transparency = 1.0f;

    // ... (configurar otros materiales según sea necesario)

    return true;
}

bool Update() {
    // Cálculo del framerate
    float currentFrame = (float)glfwGetTime();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;

    // Procesa la entrada del teclado o mouse
    processInput(window);

    // Renderizado
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 10000.0f);
    glm::mat4 view = camera.GetViewMatrix();

    // Dibujar cubemap (fondo)
    {
        mainCubeMap->drawCubeMap(*cubemapShader, projection, view);
    }

    // Dibujar modelo animado (guerrero mongol)
    {
        // Actualización de la animación
        character->UpdateAnimation(deltaTime);

        // Activación del shader del personaje
        dynamicShader->use();

        // Aplicamos transformaciones de proyección y cámara
        dynamicShader->setMat4("projection", projection);
        dynamicShader->setMat4("view", view);

        // Aplicamos transformaciones del modelo
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::translate(model, position);
        model = glm::rotate(model, glm::radians(rotateCharacter), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.01f, 0.01f, 0.01f));
        dynamicShader->setMat4("model", model);

        dynamicShader->setMat4("gBones", MAX_RIGGING_BONES, character->gBones);

        // Dibujamos el modelo
        character->Draw(*dynamicShader);
    }

    // Dibujar modelos estáticos con iluminación
    {
        // Activamos el shader de iluminación
        mLightsShader->use();
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        mLightsShader->setMat4("projection", projection);
        mLightsShader->setMat4("view", view);

        // Configuramos propiedades de luces
        mLightsShader->setInt("numLights", (int)gLights.size());
        for (size_t i = 0; i < gLights.size(); ++i) {
            SetLightUniformVec3(mLightsShader, "Position", i, gLights[i].Position);
            SetLightUniformVec3(mLightsShader, "Direction", i, gLights[i].Direction);
            SetLightUniformVec4(mLightsShader, "Color", i, gLights[i].Color);
            SetLightUniformVec4(mLightsShader, "Power", i, gLights[i].Power);
            SetLightUniformInt(mLightsShader, "alphaIndex", i, gLights[i].alphaIndex);
            SetLightUniformFloat(mLightsShader, "distance", i, gLights[i].distance);
        }

        mLightsShader->setVec3("eye", camera.Position);

        // Dibujar casa
        {
            glm::mat4 model = glm::mat4(1.0f);
            model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
            model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
            model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
            mLightsShader->setMat4("model", model);

            // Configurar material para la casa
            mLightsShader->setVec4("MaterialAmbientColor", material2.ambient);
            mLightsShader->setVec4("MaterialDiffuseColor", material2.diffuse);
            mLightsShader->setVec4("MaterialSpecularColor", material2.specular);
            mLightsShader->setFloat("transparency", material2.transparency);

            house->Draw(*mLightsShader);
        }

        // Dibujar otros modelos estáticos (muebles) de manera similar...
        // Puedes agregar aquí la renderización de sillas, mesas, etc.
    }

    // Dibujar indicadores de luces
    {
        basicShader->use();
        basicShader->setMat4("projection", projection);
        basicShader->setMat4("view", view);

        for (size_t i = 0; i < gLights.size(); ++i) {
            glm::mat4 model = glm::mat4(1.0f);
            model = glm::translate(model, gLights[i].Position);
            model = glm::rotate(model, glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
            model = glm::scale(model, glm::vec3(0.1f, 0.1f, 0.1f));
            basicShader->setMat4("model", model);
            lightDummy->Draw(*basicShader);
        }
    }

    glUseProgram(0);

    // Intercambiar buffers y eventos
    glfwSwapBuffers(window);
    glfwPollEvents();

    return true;
}

// Implementaciones de funciones auxiliares para luces
void SetLightUniformInt(Shader* shader, const char* propertyName, size_t lightIndex, int value) {
    std::ostringstream ss;
    ss << "allLights[" << lightIndex << "]." << propertyName;
    std::string uniformName = ss.str();
    shader->setInt(uniformName.c_str(), value);
}

void SetLightUniformFloat(Shader* shader, const char* propertyName, size_t lightIndex, float value) {
    std::ostringstream ss;
    ss << "allLights[" << lightIndex << "]." << propertyName;
    std::string uniformName = ss.str();
    shader->setFloat(uniformName.c_str(), value);
}

void SetLightUniformVec4(Shader* shader, const char* propertyName, size_t lightIndex, glm::vec4 value) {
    std::ostringstream ss;
    ss << "allLights[" << lightIndex << "]." << propertyName;
    std::string uniformName = ss.str();
    shader->setVec4(uniformName.c_str(), value);
}

void SetLightUniformVec3(Shader* shader, const char* propertyName, size_t lightIndex, glm::vec3 value) {
    std::ostringstream ss;
    ss << "allLights[" << lightIndex << "]." << propertyName;
    std::string uniformName = ss.str();
    shader->setVec3(uniformName.c_str(), value);
}

// Resto de funciones (processInput, callbacks, etc.) se mantienen igual que en los códigos originales
// ... [implementaciones de processInput, framebuffer_size_callback, mouse_callback, scroll_callback]
// Procesamos entradas del teclado
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_M) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    if (glfwGetKey(window, GLFW_KEY_N) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    if (glfwGetKey(window, GLFW_KEY_B) == GLFW_PRESS)
        glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);

    // Character movement
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {


    }
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {

    }
    if (glfwGetKey(window, GLFW_KEY_Y) == GLFW_PRESS) {

    }
    if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS) {

    }
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {

    }
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {

    }

}

// glfw: Actualizamos el puerto de vista si hay cambios del tamaño
// de la ventana
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: Callback del movimiento y eventos del mouse
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = (float)xpos;
        lastY = (float)ypos;
        firstMouse = false;
    }

    float xoffset = (float)xpos - lastX;
    float yoffset = lastY - (float)ypos;

    lastX = (float)xpos;
    lastY = (float)ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: Complemento para el movimiento y eventos del mouse
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll((float)yoffset);
}
